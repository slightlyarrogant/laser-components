# @cfi/mcp-widgets

Connector-agnostic, inline **MCP-Apps (ext-apps)** widgets for any MCP server.
The full palette, lifted and hardened from iKrystyna Connect's and Vendo
Connect's now-working, lesson-tested implementations (verified rendering in
Claude.ai **and** ChatGPT):

- **LIST** — a filterable, sortable data table with an optional KPI strip,
  per-column totals footer, search box, and CSV export. *(lean table)*
- **KPI** — KPI cards in a responsive grid, with an optional detail table and
  free-form notes.
- **ANALYTICS** — a multi-view analysis: a client-side pill switcher, inline
  hand-rolled SVG bar + line charts, KPI tiles, a table with a frozen first
  column, and CSV. Generic — driven entirely by `views` / `kpiStrip` / `tiles`
  / `tableCols`.
- **MESSAGES** — an accordion mail/chat list (rows expand on click) with an
  unread badge and a Wszystkie/Nieprzeczytane filter. Generic
  `NormalizedMessage[]`.
- **ACTION** — a terminal write/action confirmation: an animated CSS/SVG glyph
  (checkmark / info / warning) plus a title, optional detail, and optional id.
- **AGENDA** — a day-agenda with a view switcher (Oś czasu / Sekcje / Lista),
  expandable detail panels, and a collapsible mail toggle. Generic
  `AgendaItem[]` / `AgendaMail[]`.
- **DATASET** — a generic table with **type-aware** cell formatting
  (number / currency / percent / date / bool / status / id), a sticky header,
  client-side sort + search, injectable column curation / view switcher, a
  totals footer, and a CSV download. *(type-aware / curated table)*

> **LIST vs DATASET** — both are tables; pick by need. **LIST** is lean: you
> hand it the exact `keyColumns` and it formats by value type only. **DATASET**
> is type-aware and curated: it *infers* per-column types, flattens nested
> objects/arrays, renders status pills, and supports an injectable
> column-curation view switcher — better for wide/heterogeneous result sets.

Every widget ships the widget HTML, the tool-result envelope builder, the
server registration helper, and (for the lint) the `*_WIDGET_HTML(baseUrl)`
getter. A shared SDK-serving helper and a rule-enforcing lint cover all of them.
No connector-specific field names, label maps, URLs, or env vars are baked in —
`baseUrl` is always a parameter, and any connector-specific column labels /
curation are injectable (default identity / passthrough).

---

## The 5 rules (every widget MUST follow; the lint enforces them)

These are hard-won (each was a real, silent cause of a blank iframe). They are
documented in iKrystyna's `WIDGET_GUIDELINES.md §0` and enforced by
`npm run lint:widgets`.

1. **Widget script is `<script type="module">`** — not classic `<script>`+IIFE.
   The sandbox reliably runs inline modules; the IIFE form did not.
2. **No `height:100vh` / `100vh` / `100dvh`** on body/root. The iframe height is
   content-driven (the host's `autoResize`); `100vh` fights it and collapses the
   widget to 0. Use natural flow + a `max-height` scroll container
   (`.wrap{max-height:440px;overflow:auto}`).
3. **Zero inline event handlers** (`onclick=`, `oninput=`, …) in the HTML — the
   sandbox CSP blocks them. Bind via `addEventListener` / event delegation in
   the module script.
4. **Minimal static `<body>`** (just a status div). Build ALL interactive UI in
   JS (`document.body.innerHTML = …`). Do not ship a static skeleton of
   `<input>/<button>/<table>`.
5. **Zero raw `\r\n` (and `\uXXXX`, other `\`-escapes) inside the
   template-literal that holds the widget HTML/JS.** A backtick interprets
   `\r\n` as a real CRLF → an unterminated string in the served `<script>` →
   SyntaxError → blank iframe. `tsc` does NOT catch this (the JS lives in a
   string). In source, **double the backslashes** (`'\\r\\n'`, `'\\ufeff'`) so
   the served script contains the literal escape sequence. This was the silent
   killer in iKrystyna's CSV export.

---

## Install

```bash
npm install @cfi/mcp-widgets
# peers provided by your connector:
npm install @modelcontextprotocol/sdk @modelcontextprotocol/ext-apps
```

`@modelcontextprotocol/sdk` and `@modelcontextprotocol/ext-apps` are declared as
dependencies; your connector already depends on the same `ext-apps` whose
browser SDK gets served (see below), so versions stay in lockstep.

---

## Public API (`@cfi/mcp-widgets`)

```ts
// Types (all connector-agnostic — no baked field names)
import type {
  ListRow, ListKpi, ListMeta,
  KpiItem, KpiTable, KpiMeta,
  WidgetEnvelope,
  // analytics
  AnalyticsKind, AnalyticsKpiItem, AnalyticsChartData, AnalyticsRow,
  AnalyticsColFmt, AnalyticsTableCol, AnalyticsView, AnalyticsMeta,
  // messages
  MessagesKind, NormalizedMessage, MessagesMeta,
  // action
  ActionStatus, ActionMeta,
  // agenda
  AgendaItem, AgendaMail, AgendaCounts, AgendaMeta,
  // dataset
  DatasetSchemaColumn, DatasetSchema, DatasetView, DatasetMeta, DatasetRow,
} from '@cfi/mcp-widgets'

// Shared theme tokens (CSS string)
import { THEME_TOKENS } from '@cfi/mcp-widgets'

// SDK serving helper
import {
  WIDGET_SDK_PATH,          // '/widget-sdk/app.js'
  WIDGET_SDK_CONTENT_TYPE,  // 'application/javascript'
  getWidgetSdkPath,         // absolute path to ext-apps app-with-deps.js
  getWidgetSdkJs,           // its contents (read once, cache)
} from '@cfi/mcp-widgets'

// LIST widget
import {
  LIST_WIDGET_URI,    // bind tools via _meta.ui.resourceUri
  buildListEnvelope,  // (meta: ListMeta, steer: string) => WidgetEnvelope
  registerListWidget, // (server, baseUrl) => void
  LIST_WIDGET_HTML,   // (baseUrl) => served HTML (used by the lint)
} from '@cfi/mcp-widgets'

// KPI widget
import {
  KPI_WIDGET_URI,
  buildKpiEnvelope,   // (meta: KpiMeta, steer: string) => WidgetEnvelope
  registerKpiWidget,
  KPI_WIDGET_HTML,
} from '@cfi/mcp-widgets'

// ANALYTICS widget
import {
  ANALYTICS_WIDGET_URI,
  buildAnalyticsEnvelope,  // (meta: AnalyticsMeta, steer: string) => WidgetEnvelope
  registerAnalyticsWidget, // (server, baseUrl) => void
  ANALYTICS_WIDGET_HTML,   // (baseUrl) => served HTML (used by the lint)
} from '@cfi/mcp-widgets'

// MESSAGES widget
import {
  MESSAGES_WIDGET_URI,
  buildMessagesEnvelope,   // (meta: MessagesMeta, steer: string) => WidgetEnvelope
  registerMessagesWidget,  // (server, baseUrl) => void
  MESSAGES_WIDGET_HTML,
} from '@cfi/mcp-widgets'

// ACTION (confirmation) widget
import {
  ACTION_WIDGET_URI,
  buildActionEnvelope,     // (meta: ActionMeta, steer?: string) => WidgetEnvelope
  registerActionWidget,    // (server, baseUrl) => void
  ACTION_WIDGET_HTML,
} from '@cfi/mcp-widgets'

// AGENDA widget
import {
  AGENDA_WIDGET_URI,
  buildAgendaEnvelope,     // (meta: AgendaMeta, steer: string) => WidgetEnvelope
  registerAgendaWidget,    // (server, baseUrl) => void
  AGENDA_WIDGET_HTML,
} from '@cfi/mcp-widgets'

// DATASET widget
import {
  DATASET_WIDGET_URI,
  DATASET_WIDGET_FULL_CAP, // default delivery cap (5000) for _meta.rows
  buildDatasetEnvelope,    // (meta: DatasetMeta, steer: string) => WidgetEnvelope
  registerDatasetWidget,   // (server, baseUrl) => void
  DATASET_WIDGET_HTML,
} from '@cfi/mcp-widgets'
```

### LIST — `ListMeta`

| field          | type                                  | notes |
|----------------|---------------------------------------|-------|
| `title`        | `string`                              | table heading |
| `rows`         | `ListRow[]`                           | bulk data (delivered via `_meta`; the model does not see it) |
| `keyColumns`   | `string[]`                            | column keys in display order |
| `columnLabels` | `Record<string,string>?`              | per-column display labels; **default identity** (the column key). This replaces iKrystyna's hard-coded label map — inject your own here. |
| `csvStem`      | `string?`                             | CSV filename stem |
| `kpiStrip`     | `ListKpi[]?`                          | compact KPI tiles above the table |
| `totals`       | `Record<string,number>?`             | per-column numeric totals in the footer |

Cells are formatted generically by **value type**: numbers are right-aligned
and `pl-PL`-formatted, booleans as ✓/✗, `null`/empty as an em-dash, everything
else HTML-escaped as text. No magic column-name heuristics.

### KPI — `KpiMeta`

| field    | type                  | notes |
|----------|-----------------------|-------|
| `title`  | `string`              | heading |
| `period` | `string?`             | sub-heading |
| `kpis`   | `KpiItem[]`           | cards; `format`: `'pln' | 'int' | 'text' | 'percent'`, `accent`, `note` |
| `table`  | `KpiTable?`           | optional detail table (`columns`, `labels?` default identity, `rows`) |
| `notes`  | `string[]?`           | free-form footer notes |

### ANALYTICS — `AnalyticsMeta`

| field       | type                  | notes |
|-------------|-----------------------|-------|
| `title`     | `string`              | header title |
| `period`    | `{from?,to?}?`        | pre-formatted period strings shown in the header |
| `kpiStrip`  | `AnalyticsKpiItem[]`  | always-visible header strip; `kind`: `'currency'|'int'|'number'`, `accent` |
| `tableCols` | `AnalyticsTableCol[]?`| curated-table column spec; frozen first column = key `"Nazwa"`; `fmt` + optional `total` (footer) |
| `views`     | `AnalyticsView[]`     | switchable views; `kind`: `'bar'|'line'|'kpi'`; carries `rows` (key `Nazwa` + optional `Kod`), `chart`, `tiles` |
| `csvStem`   | `string?`             | CSV filename stem (widget appends `-<viewId>.csv`); default `'analiza'` |
| `note`      | `string?`             | optional always-visible muted caption |
| `counts`    | `Record<string,number>?` | per-view row counts for `structuredContent`; derived when omitted |

Pill switcher / sort / search / CSV are all client-side; the widget never calls
back. Connector-agnostic: only `Nazwa`/`Kod` are reserved layout keys — every
other measure is referenced by `tableCols[].key`. Your tool projects its data
into `views`/`kpiStrip`/`tableCols`.

### MESSAGES — `MessagesMeta`

| field      | type                  | notes |
|------------|-----------------------|-------|
| `title`    | `string`              | header title |
| `kind`     | `MessagesKind`        | `'mail'|'chat'|'mixed'` (drives row glyphs/tags) |
| `messages` | `NormalizedMessage[]` | bulk (bodies in `_meta`); each: `id,source,sender,subject,preview,body,ts,unread` |
| `capped`   | `boolean?`            | honest "first N" note when the source list was capped |

Accordion expand/collapse and the Wszystkie/Nieprzeczytane filter are
client-side.

### ACTION — `ActionMeta`  (`buildActionEnvelope(meta, steer?)`)

| field     | type            | notes |
|-----------|-----------------|-------|
| `status`  | `ActionStatus?` | `'success'|'info'|'warning'` → glyph + accent; default `'success'` |
| `icon`    | `string?`       | explicit glyph override (emoji); normally omit |
| `title`   | `string`        | bold headline (required) |
| `detail`  | `string?`       | secondary line |
| `id`      | `string?`       | id/number value |
| `idLabel` | `string?`       | label for the id line |

Terminal widget (no callbacks). `steer` is **optional** — omit it for a generic
one-line confirmation steer. Animated CSS/SVG glyph; honours
`prefers-reduced-motion`.

### AGENDA — `AgendaMeta`

| field       | type            | notes |
|-------------|-----------------|-------|
| `date`      | `string`        | raw day key (header fallback) |
| `dateLabel` | `string?`       | pre-formatted human label (e.g. `"piątek, 31 maja"`) |
| `user`      | `string?`       | owner/acting-user name |
| `counts`    | `AgendaCounts?` | `{meetings,tasks,mails}`; derived when omitted |
| `meetings`  | `AgendaItem[]`  | meeting entries (each has time/title/detail fields; `category:'meeting'`) |
| `tasks`     | `AgendaItem[]`  | task entries (`category:'task'` or omitted) |
| `mails`     | `AgendaMail[]`  | collapsed mail entries |

View switcher (Oś czasu / Sekcje / Lista), per-item expand, and the mail toggle
are client-side. Port the WIDGET only — fetch/normalize your calendar data into
these shapes in your own tool handler. `AgendaItem.category` (was Vendo's
`__cat`) buckets meetings vs tasks.

### DATASET — `DatasetMeta`  (type-aware / curated table)

| field        | type             | notes |
|--------------|------------------|-------|
| `datasetId`  | `string`         | stable id (also returned to the model) |
| `title`      | `string`         | table heading |
| `rows`       | `DatasetRow[]`   | bulk (in `_meta`); open bag per row (nested objects/arrays allowed) |
| `rowCount`   | `number?`        | server-side total (may exceed `rows.length` when capped); default `rows.length` |
| `schema`     | `DatasetSchema?` | soft per-column type hints (`{columns:[{name,type?,unit?}]}`) |
| `columns`    | `string[]?`      | **injectable** initial (curated) columns; **default = row keys** |
| `views`      | `DatasetView[]?` | **injectable** column-curation view switcher (`{id,label,columns}`) |
| `allColumns` | `string[]?`      | full relevant column superset (for the "all columns" pill) |
| `capped`     | `boolean?`       | true when `rowCount > cap`; default derived |
| `cap`        | `number?`        | delivery cap; default `DATASET_WIDGET_FULL_CAP` (5000) |
| `incomplete` | `boolean?`       | partial first batch → hides the totals footer, shows a "narrow your search" bar |
| `exportUrl`  | `string?`        | full-dataset CSV/Excel URL (toolbar download button) |

The widget *infers* per-column types and formats accordingly, flattens nested
objects/arrays, renders status pills, totals summable columns, and sorts/
searches client-side. **Column curation is connector-specific and injectable**:
compute your own `columns`/`views`/`allColumns` (this library does NOT ship an
entity detector — that stays in your connector) and pass them in; omit them and
the widget falls back to the raw row keys (identity/passthrough).

### MAP — `MapMeta`  (choropleth heat-map)

| field           | type                      | notes |
|-----------------|---------------------------|-------|
| `title`         | `string?`                 | header; default `'Mapa'` |
| `scope`         | `'europe' \| 'world'`     | initial pill; default `'europe'` |
| `unit`          | `string?`                 | suffix in tooltip + legend (`'szt.'`, `'PLN'`) |
| `values`        | `Record<alpha2, number>`  | bulk (in `_meta`); ISO 3166-1 alpha-2 (uppercase) |
| `names`         | `Record<alpha2, string>?` | per-code display-name overrides (default: bundled English name) |
| `palette`       | `string?`                 | **named** ramp; default `'oranges'`. Unknown → `'oranges'` |
| `paletteBins`   | `number?`                 | bucket count for quantile/threshold; default `5` |
| `paletteBreaks` | `number[]?`               | explicit ascending cut-points; only used by a `'threshold'`-scale ramp |

**Named palettes** (the LIBRARY owns the ramps — `PALETTES` / `PALETTE_NAMES`):
sequential `oranges` · `blues` · `greens` · `purples` · `viridis` · `heat`
(YlOrRd); diverging `rdylgn` · `rdbu`. Sequential ramps default to a **quantile**
scale (5 bins), diverging to **linear**. Ramps are baked hex stop arrays
(ColorBrewer — free for any use; viridis — CC0); no `d3-scale-chromatic` at
runtime. The scale builder `buildColorScale(palette, values, {bins?, breaks?})`
supports `linear` (gradient legend), `quantile` (bin legend with human range
labels like `1–3` / `11+`), `log` (log10, guards ≤0), and `threshold` (explicit
breaks; falls back to quantile when none given). No-data → neutral grey.

**Palette is a CONNECTOR/TENANT choice, not an LLM parameter.** A connector reads
its tenant/client config and passes the name into the envelope:

```ts
// connector side — name comes from tenant config, NEVER from the model
const palette = tenant.mapPalette ?? 'oranges'           // e.g. 'viridis', 'heat'
buildMapEnvelope({ title, scope, unit, values, palette }, steer)
```

The model never sees or chooses the palette (it is not a tool parameter and
there is no client-side switcher). The library owns the named ramps; the
connector owns the client→palette-name mapping. The scale is recomputed
client-side per active scope (Europa/Świat) over only the countries in that
geometry. Preview the readability win standalone:
`node scripts/build-preview-map.mjs && open scripts/preview-map.html`
(oranges-linear vs oranges-quantile vs viridis-quantile + a `PALETTE_NAMES`
swatch gallery); prove it headless: `node scripts/verify-map-palette.mjs`.

### CHAT-INBOX — `ChatInboxMeta`  (`buildChatInboxEnvelope(meta, steer)`)

WhatsApp-style conversation inbox + reply. URI `ui://cfi-widgets/chat-inbox-v1`.
Responsive two-pane (conversation list + thread), mobile single-pane drill-in,
fullscreen via `app.requestDisplayMode` (with the `--fs-bottom` reserve), and a
reply composer that calls a server tool.

| field           | type                          | notes |
|-----------------|-------------------------------|-------|
| `title`         | `string`                      | header |
| `selfId`        | `number?`                     | session user's id (own-message alignment hint) |
| `conversations` | `ChatInboxConversation[]`     | bulk (threads in `_meta`); each: `id,name,isGroup,lastText,lastTs,lastSenderName,unread,messages[],notPrefetched?` |
| `capped`        | `boolean?`                    | honest "first N" note |
| `tools`         | `{ reply?: string }?`         | connector's reply server-tool name; default `'reply_in_conversation'` |

### MAIL-INBOX — `MailInboxMeta`  (`buildMailInboxEnvelope(meta, steer)`)

Gmail-style mail inbox + reply. URI `ui://cfi-widgets/mail-inbox-v1`. List +
full email detail (recipient chips, "reply all" recipient selection), reply
composer, prefetched bodies in `_meta`, fullscreen.

| field        | type                                 | notes |
|--------------|--------------------------------------|-------|
| `title`      | `string`                             | header |
| `mails`      | `MailInboxMail[]`                    | bulk (bodies in `_meta`); each: `id,mailId,senderName,senderEmail,recipients,cc,subject,bodyHtml,bodyText,preview,ts,unread` |
| `capped`     | `boolean?`                           | honest "first N" note |
| `selfEmail`  | `string?`                            | session user's own address — excluded from "reply all" |
| `tools`      | `{ reply?: string; body?: string }?` | connector tool names; defaults `'reply_to_email'` / `'get_mail_body'` |

**Connector-agnostic tool names.** Both inbox widgets read their server-tool
names from `meta.tools` (threaded into the envelope `_meta`), falling back to the
current Vendo names when a connector does not override — so behaviour is
unchanged if `tools` is omitted. The data shape (conversations / mails) stays as
authored by the connector; the library widget just renders `result._meta`.

---

## Wire it into a connector

```ts
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js'
import { registerAppTool } from '@modelcontextprotocol/ext-apps/server'
import {
  registerListWidget,      buildListEnvelope,      LIST_WIDGET_URI,
  registerKpiWidget,       buildKpiEnvelope,       KPI_WIDGET_URI,
  registerAnalyticsWidget, buildAnalyticsEnvelope, ANALYTICS_WIDGET_URI,
  registerMessagesWidget,  buildMessagesEnvelope,  MESSAGES_WIDGET_URI,
  registerActionWidget,    buildActionEnvelope,    ACTION_WIDGET_URI,
  registerAgendaWidget,    buildAgendaEnvelope,    AGENDA_WIDGET_URI,
  registerDatasetWidget,   buildDatasetEnvelope,   DATASET_WIDGET_URI,
  getWidgetSdkJs, WIDGET_SDK_PATH, WIDGET_SDK_CONTENT_TYPE,
} from '@cfi/mcp-widgets'

const BASE_URL = process.env.PUBLIC_BASE_URL!   // e.g. https://my-connector.ngrok.app

// 1) Serve the ext-apps SDK from your own origin (read once, cache).
//    Must be app-with-deps.js (bundled) — the helper resolves that for you.
const SDK = getWidgetSdkJs()
// Hono example:
//   app.get(WIDGET_SDK_PATH, () =>
//     new Response(SDK, { headers: { 'Content-Type': WIDGET_SDK_CONTENT_TYPE } }))
// Express example:
//   app.get(WIDGET_SDK_PATH, (_req, res) =>
//     res.type(WIDGET_SDK_CONTENT_TYPE).send(SDK))

// 2) Register the widget resources (per MCP server instance).
function buildServer() {
  const server = new McpServer({ name: 'My Connector', version: '1.0.0' })
  registerListWidget(server, BASE_URL)
  registerKpiWidget(server, BASE_URL)
  registerAnalyticsWidget(server, BASE_URL)
  registerMessagesWidget(server, BASE_URL)
  registerActionWidget(server, BASE_URL)
  registerAgendaWidget(server, BASE_URL)
  registerDatasetWidget(server, BASE_URL)

  // 3) Bind a tool to a widget in its DEFINITION via _meta.ui (Claude.ai) and
  //    "openai/outputTemplate" (ChatGPT) — binding only in the RESULT is not enough.
  registerAppTool(server, 'list_things', {
    title: 'Things',
    description: 'Returns things as an inline table widget.',
    inputSchema: {},
    annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false },
    _meta: {
      ui: { resourceUri: LIST_WIDGET_URI },
      'openai/outputTemplate': LIST_WIDGET_URI,
    },
  }, async () => {
    const rows = await fetchThings()                    // YOUR data
    return buildListEnvelope({
      title: 'Things',
      rows,
      keyColumns: ['id', 'name', 'amount'],
      columnLabels: { id: 'ID', name: 'Name', amount: 'Amount' },  // injectable
      csvStem: 'things',
      totals: { amount: rows.reduce((s, r) => s + Number(r.amount ?? 0), 0) },
    }, '[PRESENTATION] Showing N things in the widget — do not re-list rows in text.')
  })

  return server
}
```

### KPI tool result

```ts
return buildKpiEnvelope({
  title: 'Monthly summary',
  period: '05.2026',
  kpis: [
    { label: 'Revenue', value: 123456.78, format: 'pln', accent: true },
    { label: 'Invoices', value: 42, format: 'int' },
  ],
  table: {
    columns: ['category', 'net', 'vat'],
    labels: { category: 'Category', net: 'Net', vat: 'VAT' },
    rows: [{ category: 'A', net: 1000, vat: 230 }],
  },
  notes: ['Computed from issued invoices only.'],
}, '[PRESENTATION] Summary shown in the widget — do not restate all numbers.')
```

### After deploying a widget/definition change

The host **caches the tool schema and widget HTML**. After you change widget
HTML, `_meta`, or a tool definition, the client keeps rendering the old
(possibly broken) version until you refresh:

- **Claude.ai:** Customize → Connectors → your connector → ⋮ → **Refresh tools list**.
- **ChatGPT:** Settings → Apps → your connector → **Refresh**.

Then start a **new chat** and re-invoke the tool. Runtime values in the result
(`content` / `structuredContent` / `_meta`) arrive immediately; the widget HTML
and definition do not until the refresh. (A stateless endpoint has no
`notifications/tools/list_changed`, so the refresh is manual.)

---

## The lint — `npm run lint:widgets`

The safety net. For each widget it obtains the **exact served HTML** (via the
`*_WIDGET_HTML(baseUrl)` getter) and checks:

- **Rule 1** — contains `<script type="module">`, and no classic `<script>`
  does a dynamic `import(`.
- **Rule 5** — no raw carriage-return (0x0D) and no raw U+2028/U+2029 in the
  served HTML; and every `<script type="module">` block is **parsed with the
  TypeScript compiler API** (`ts.transpileModule`, diagnostics captured) —
  any SyntaxError fails. This is what directly catches the
  `\r\n`-in-template-literal trap that `tsc` on the `.ts` source cannot see.
- **Rule 3** — no inline event-handler attributes (` on\w+=`) in the static HTML.
- **Rule 2** — no `100vh` / `100dvh` in the CSS.
- **Rule 4** (best-effort) — warns if the static `<body>` contains
  `<table>/<input>/<button>` outside the module script.

It exits non-zero (printing widget name + which rule) on any failure, so it
gates CI. Run it after `npm run build` (it executes the compiled
`dist/lint/check-widgets.js`).

```bash
npm run build
npm run lint:widgets
```

---

## Build

```bash
npm install      # installs deps (ext-apps, sdk, typescript)
npm run build    # tsc -> dist/
npm run lint:widgets
```

ESM / NodeNext, strict TypeScript. Node ≥ 20.
